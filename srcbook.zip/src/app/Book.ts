export class Book{
code:number;
bname:string;
author:string;
genre:string;
}