import { Injectable } from '@angular/core';
import { Book } from './Book';

@Injectable({
  providedIn: 'root'
})
export class BookService {

  constructor() { }
  books:Map<number,Book>=new Map<number,Book>();
}
