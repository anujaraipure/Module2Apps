import { Component, OnInit } from '@angular/core';
import { Book } from '../Book';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
 genre:string[]=["auto-biography","biography","sci-fi","horror","drama"];
  imgsrc:string="./assets/images.jpg";
  imgsrc1:string="./assets/girl.jpg";
  
insert(){
  
 
}
show(data):void{  
  alert(`Code: ${data.code} Name: ${data.name} Author: ${data.author} Genre: ${data.genre}`);
}
onClickSubmit(d) {
  alert("Entered Email id : " + d.emailid);
}
}
